﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Send mail from SDN1
                string MailServer = "smtp.gmail.com";
                string MailUN = "tehila@carmel-tech.com";
                string MailPass = "tehila123456789";
                string MailPort = "587";

                System.Net.Mail.SmtpClient smtpClient = new System.Net.Mail.SmtpClient();
                smtpClient.Host = MailServer;
                smtpClient.UseDefaultCredentials = false;
                if (!string.IsNullOrEmpty(MailPort))
                    smtpClient.Port = Convert.ToInt32(MailPort);
                //smtpClient.Port = 587;
                smtpClient.Credentials = new System.Net.NetworkCredential(MailUN, MailPass);
                smtpClient.Timeout = 200000;
                MailMessage msg = new MailMessage("liat@carmel-tech.com", "liat@carmel-tech.com");
                //msg.Subject = "[tag: Gear]" + msg.Subject;
                msg.Subject = "this is test message from liat amir";

                smtpClient.SendAsync(msg, null);
                File.AppendAllText("c:\\maillog.txt", "done " + DateTime.Now + Environment.NewLine);
            }
            catch (Exception ex)
            {
                File.AppendAllText("c:\\maillog.txt", ex.ToString() + "   " + DateTime.Now + Environment.NewLine);
            }

        }
    }
}
