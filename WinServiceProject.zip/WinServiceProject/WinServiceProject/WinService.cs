﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Configuration;
using WinServiceProject.KPI;



namespace WinServiceProject
{
    using System;
    using System.IO;
    using System.Diagnostics;
    

    class WinService : System.ServiceProcess.ServiceBase
    {
        System.Timers.Timer sendXml_timer = new System.Timers.Timer();
        public WinService()
        {
            this.ServiceName = "kpiNew";
           // this.EventLog = new System.Diagnostics.EventLog();
            //this.EventLog.Source = this.ServiceName;
            this.EventLog.Source = "KPIEvents";
            
            //this.EventLog.Log = "Application";
            this.EventLog.Log = "KPI Event Viewer";
            if (!EventLog.SourceExists(this.EventLog.Source))
            {
                EventLog.CreateEventSource(this.EventLog.Source, this.EventLog.Log);
            }

        }
        // The main entry point for the process
        static void Main()
        {
            System.ServiceProcess.ServiceBase[] ServicesToRun;
            ServicesToRun = new System.ServiceProcess.ServiceBase[] { new WinService() };
            System.ServiceProcess.ServiceBase.Run(ServicesToRun);
            
        }
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ServiceName = "kpiNew";
        }
        
        /// <summary>
        /// Set things in motion so your service can do its work.
        /// </summary>
        protected override void OnStart(string[] args)
        {
            System.Diagnostics.Debugger.Launch();
            
            EventLog.WriteEntry("KPIEvents","service kpi start on: "+DateTime.Now.ToString());
            
            //sendXml_timer.Interval = 15000;
            sendXml_timer.Interval = Convert.ToDouble(ConfigurationManager.AppSettings["Interval"]);
            sendXml_timer.AutoReset = true;
            sendXml_timer.Elapsed += new System.Timers.ElapsedEventHandler(xml_timer_Elapsed);
            sendXml_timer.Start();
            
           
        }
        /// <summary>
        /// Stop this service.
        /// </summary>
        protected override void OnStop()
        {
            EventLog.WriteEntry("KPIEvents", "service kpi stop on:  " + DateTime.Now.ToString());
        }


        void xml_timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            EventLog.WriteEntry("KPIEvents", "xml_timer_Elapsed now:  " + DateTime.Now.ToString());
            sendXml();
        }



        public void sendXml()
        {

            Console.WriteLine("webrequest");
            string url = ConfigurationManager.AppSettings["url"];
            HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(url);
            NameValueCollection nvc = new NameValueCollection();
            //nvc.Add("id", "TTR");
            nvc.Add("email", "EMAIL_HERE");
            nvc.Add("password", "PASSWORD_HERE");
            string folderPath = ConfigurationManager.AppSettings["path"];

            try
            {
                foreach (string file in Directory.EnumerateFiles(@"" + folderPath, "*.xml"))
                {
                    // string contents = File.ReadAllText(file);

                    string pathFile = file;
                    String info = Post_File.HttpUploadFile(url, @"" + pathFile, "uploadfile", "application/xml", nvc);
                }
            }
            catch(Exception ex)
            {
                EventLog.WriteEntry("KPIEvents", "could not do foreach on the files in the folder: " + folderPath);
            }


            //string pathFile = ConfigurationManager.AppSettings["Path"];
            //String info = Post_File.HttpUploadFile(url, @"" + pathFile, "uploadfile", "application/xml", nvc);
            

            //Console.Write(info);
            //Console.Read();
        }

    }
}