﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace WindowsServicebyshira
{
    public partial class Service1 : ServiceBase
    {
        System.Timers.Timer timer = new System.Timers.Timer();
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            timer.Interval = 1000 * 60;
            timer.AutoReset = true;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(printmessage);
            timer.Start();
            printmessage(null, null);  
        }

        protected override void OnStop()
        {

        }
        void printmessage(object sender, System.Timers.ElapsedEventArgs e)
        {
            Console.WriteLine("hello world");
        }
    }
       
   
}
